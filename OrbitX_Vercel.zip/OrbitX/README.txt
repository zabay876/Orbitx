OrbitX — static HTML demo prepared for Vercel

Deployment:
1. Upload this folder to a GitHub repository (index.html, vercel.json, README.txt).
2. Sign in to Vercel and choose Add New -> Project.
3. Import the GitHub repository.
4. Keep Framework Preset as Other; leave Build Command and Output Directory empty.
5. Press Deploy.

Note: This is a front-end demo. Real accounts, cross-device messaging, calls, and TON payments need a backend and secure integrations. Do not use a real password in this demo.
